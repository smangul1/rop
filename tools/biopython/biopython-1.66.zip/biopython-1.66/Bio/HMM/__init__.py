# make files in this directory importable
"""A selection of Hidden Markov Model code."""
